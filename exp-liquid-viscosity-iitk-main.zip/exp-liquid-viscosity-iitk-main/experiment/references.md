1. https://www.niser.ac.in/sps/sites/default/files/basic_page/viscosity_2016.pdf<br>
2. https://www.iitr.ac.in/departments/PH/uploads/Teaching%20Laboratory/8%20Stokes%20Law.pdf<br>
3. https://www.teachengineering.org/activities/view/cub_surg_lesson03_activity1<br>
4. https://aip.scitation.org/doi/am-pdf/10.1063/1.4948314<br>
5. https://iopscience.iop.org/article/10.1088/1742-6596/1294/2/022002/pdf

