1.Select the liquid (Water/Kerosene/ Alcohol) from the drop down.<br>
2.Select the material of ball (Stone/Iron/gold) from the drop down.<br>
3.Enter ball radius between 10 cm to 35 cm.<br>
4.Click on submit button.<br>
5.Drag the ball to the top of the JAR.<br>
6.Note the distance appearing in the information box and time in the stopwatch.<br>
7.Note down this distance and the time in the datatable.<br>
8.Repeat the experiment for different values of the distance.<br>
9.When the table is completely filled click on plot to get the graph.<br>
10.Calculate the slope of the graph.<br>
11.Enter the value of the calculated viscosity in the "Enter viscosity" box.<br>
12.Click on % error to calculate the error in the calculated value of viscosity.<br>
13.Repeat the experiment for different liquids and different materials of the balls

