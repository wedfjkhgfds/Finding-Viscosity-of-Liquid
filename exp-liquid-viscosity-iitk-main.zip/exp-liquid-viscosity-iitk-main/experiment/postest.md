## Post test
<br>
1. On increasing the radius of the steel ball to double its value the terminal velocity of the ball become box:<br>
a) Double<br>		
<b>b) four times</b>	<br>	
c) eight times	<br>
d) sixteen times<br><br>
2. On increasing density of material of the falling ball its terminal velocity:<br>
<b>a) Increase</b>		<br>
b) decrease		<br> 
c) remains same<br>	
d) NOT<br><br>
3. On increasing density of the liquid in which ball is falling (keeping other parameters same), the terminal velocity of the body will:<br>
 a) Increase	<br>	
 <b>b) decrease</b>	<br>	
 c) remains same<br>	
 d) NOT<br><br>

4. On increasing viscosity of the liquid in which ball is falling (keeping other parameters same), the terminal velocity of the body will:<br>
 a) Increase	<br>
 <b>b) decrease</b>	<br>
 c) remains same	<br>
 d) NOT


