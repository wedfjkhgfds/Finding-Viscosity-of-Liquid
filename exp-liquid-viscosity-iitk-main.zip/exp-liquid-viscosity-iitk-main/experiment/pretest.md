## <b> Pre-test
#### Please attempt the following questions

1. The principle on which the viscosity measurement experiment based is:<br>
<b>a) Stokes’s law</b>	<br>	b) Reynolds’s law	<br>	 c) Ohm’s law	<br>	 d) Coulomb’s law<br><br>

2. In viscosity measurement experiment on increasing the temperature of liquid the terminal velocity of the ball:<br>
<b>a) Increase</b>	<br>		b) decrease	<br>	 c) remains same<br>	 d) NOT<br><br>

3. When anybody inside liquid achieves terminal velocity then the net force acting on the body is:<br>
<b>a) Zero</b>		<br>	b) acting upwards	<br>	 c) acting downwards<br>	 d) NOT<br><br>

4. The SI physical unit of viscosity is <br>
<b>a) Pascal-second</b>	<br>	b) N.s/m	<br>	 c) kg/ms2	<br> d) NOT




