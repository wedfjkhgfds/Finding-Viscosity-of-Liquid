To find Viscosity of Liquid 
