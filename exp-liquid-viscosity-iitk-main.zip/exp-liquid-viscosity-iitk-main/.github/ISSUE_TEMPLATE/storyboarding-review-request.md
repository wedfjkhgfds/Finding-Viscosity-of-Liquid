---
name: Storyboarding Review Request
about: Get your storyboarding reviewed
title: Request for Review of Storyboard
labels: storyboarding
assignees: ''

---

## *Storyboarding review Request*

1. **Exp Name**:<!--Name of the experiment-->
2. **Domain**:<!-- Domain of the experiment-->
3. **Discipline**:<!-- Discipline of the experiment-->
4. **Link to the pedagogy document**: { ../storyboard/README.md]
